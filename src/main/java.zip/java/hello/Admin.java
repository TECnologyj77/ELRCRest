package hello;

/**
 * Created by Thomas on 1/31/2017.
 */

public class Admin {

    public Admin(){

    }
}
